<?php

// var setting 

$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$num=$_REQUEST['num'];
$appointment_description=$_REQUEST['appointment_description'];
$date=$_REQUEST['date'];
$time=$_REQUEST['time'];
$duration=$_REQUEST['duration'];


//check

if ( empty($name) || empty($email) || empty($num) || empty($appointment_description) || empty($date) || empty($time) || empty($duration) )
{
echo "Please fill all the fields.";
}

else 
{

mail("ritusharma@mmumullana.org", "Appointment Request", " Name:  $name \nEmail: $email \nMobile Number: $num \nMessage: $appointment_description \nDate: $date \nTime: $time \nDuration: $duration \n",  "From: $name <$email>");

echo "<script type='text/javascript'>alert('message send successfully.');
 location.replace('https://abc.com/faculty.html')
</script>";

}

?>