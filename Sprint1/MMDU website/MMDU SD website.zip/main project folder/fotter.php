<html>
<style>

.footerr
{
    
border-top: 5px solid #02FE6F;
    
padding: 50px;
    
margin: 0px;
    
color: white;


background-image: url("coding2.gif");
}

.footerr1
{    
padding: 2px;
    
margin: 0px;

background-image: url("coding2.gif");
}

</style>
<body>
<div class="footerr">

<img height="70px" width="170px" src="Mmu.jpg"></h1> 
<img height="70px" width="70px" src="mmu1.jpg"></h1> 
<p></p>
<a href="https://github.com/ayushkamboz/ProjectLab_Team1"><img src="github.png" height="50px" width="50px" align="right"/></a>
<a href="https://www.linkedin.com/school/maharishi-markandeshwar-university-mullana/"><img src="linkedin.png" height="50px" width="50px" align="right"/></a>
<a href="https://mail.google.com/mail/u/0/#inbox?compose=CllgCKHRLhqTjbZjxvlRGNXtltmPpJZwdJHHwNpQcmGzFnrrPlZVwXSfvBWLMxBNpdFHqzLsKgV"><img src="email.png" height="50px" width="50px" align="right"/></a>
<a href="https://twitter.com/mmumullana/"><img src="twitter.png" height="50px" width="50px" align="right"/></a>
<a href="https://www.facebook.com/MMDUmullana/"><img src="facebook.png" height="50px" width="50px" align="right"/></a>

<p></p>

<div class="footerr1" >
<p></p>
</div>
</div>

</body>
</html>